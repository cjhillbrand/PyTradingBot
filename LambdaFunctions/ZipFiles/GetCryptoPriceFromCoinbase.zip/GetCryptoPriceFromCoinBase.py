import boto3
import psycopg2
from coinbase.wallet import client as cl

client = boto3.client('ssm');

def lambda_handler(event, context):

    # Grab all of the parameters from SSM
    name = client.get_parameter(Name='/CryptoName')
    cbkey = client.get_parameter(Name='/Coinbase/key') # To Do add to Parameter store
    cbsecret = client.get_parameter(Name='/Coinbase/secret') # To Do add to parameter store
    db_hostname = client.get_parameter(Name='/Database/hostname')
    db_username = client.get_paramter(Name='/Database/username')
    db_password = client.get_parameter(Name='/Database/password')
    db_database = client.get_parameter(Name='/Database/database')

    # Query the database for the Coinbase values 
    cb_client = cl.Client(cbkey, cbsecret)    
    price = cb_client.get_spot_price(currency_pair=name + '-USD')


    db_value = {'Price': price['amount'], 'Time': utc_now}

    # insert into Database.
    conn = psycopg2.connect(host=db_hostname, user=db_username, password=db_password, dbname=db_database)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO dailycryptodata (symbol, dattime, price) VALUES (" + name +", CURRENT_TIMESTAMP, " +
                price['Price'] + " )")
    
    # Commit Transaction
    conn.commit()

    # close Connection
    conn.close()

    return {'statusCode': 200}    
